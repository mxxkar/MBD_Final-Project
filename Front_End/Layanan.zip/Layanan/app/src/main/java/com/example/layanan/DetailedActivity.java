package com.example.layanan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.layanan.databinding.ActivityDetailedBinding;
import com.example.layanan.databinding.ActivityMainBinding;

public class DetailedActivity extends AppCompatActivity {

    ActivityDetailedBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailedBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = this.getIntent();
        if(intent != null){
            String name = intent.getStringExtra("name");
            int desc = intent.getIntExtra("desc", R.string.suroboyoDesc);
            int image = intent.getIntExtra("image", R.drawable.asset3);

            binding.detailName.setText(name);
            binding.detailDescription.setText(desc);
            binding.detailImage.setImageResource(image);

        }
    }
}