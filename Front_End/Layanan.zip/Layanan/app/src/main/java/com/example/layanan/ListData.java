package com.example.layanan;

public class ListData {
    String name;
    int desc;
    int image;

    public ListData(String name, int desc, int image) {
        this.name = name;
        this.desc = desc;
        this.image = image;
    }
}
